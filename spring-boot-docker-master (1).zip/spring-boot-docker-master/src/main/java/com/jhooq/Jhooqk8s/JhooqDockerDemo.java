package com.jhooq.Jhooqk8s;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JhooqDockerDemo {

    public static void main(String[] args) {
        SpringApplication.run(JhooqDockerDemo.class, args);
    }

}
